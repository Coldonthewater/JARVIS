"""
Tests for backend/integrations/weather_integration.py.

httpx calls are monkeypatched at the AsyncClient method level rather
than hitting the real OpenWeatherMap API — keeps tests fast, free, and
runnable with no API key or network access.
"""

import httpx
import pytest

from backend.integrations.base import IntegrationStatus
from backend.integrations.weather_integration import WeatherIntegration


class FakeResponse:
    def __init__(self, json_data: dict, status_code: int = 200):
        self._json_data = json_data
        self.status_code = status_code

    def json(self):
        return self._json_data

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("error", request=None, response=self)

    @property
    def text(self):
        return str(self._json_data)


@pytest.mark.asyncio
async def test_status_not_configured_without_api_key(monkeypatch):
    monkeypatch.setattr("backend.integrations.weather_integration.settings.openweather_api_key", None)
    integration = WeatherIntegration()
    assert await integration.get_status() == IntegrationStatus.NOT_CONFIGURED


@pytest.mark.asyncio
async def test_status_connected_with_api_key(monkeypatch):
    monkeypatch.setattr("backend.integrations.weather_integration.settings.openweather_api_key", "fake-key")
    integration = WeatherIntegration()
    assert await integration.get_status() == IntegrationStatus.CONNECTED


@pytest.mark.asyncio
async def test_execute_unknown_action_fails_gracefully(monkeypatch):
    monkeypatch.setattr("backend.integrations.weather_integration.settings.openweather_api_key", "fake-key")
    integration = WeatherIntegration()
    result = await integration.execute_action("do_a_backflip", {})
    assert result.success is False


@pytest.mark.asyncio
async def test_execute_missing_location_param_fails(monkeypatch):
    monkeypatch.setattr("backend.integrations.weather_integration.settings.openweather_api_key", "fake-key")
    integration = WeatherIntegration()
    result = await integration.execute_action("get_current_weather", {})
    assert result.success is False


@pytest.mark.asyncio
async def test_execute_without_api_key_fails(monkeypatch):
    monkeypatch.setattr("backend.integrations.weather_integration.settings.openweather_api_key", None)
    integration = WeatherIntegration()
    result = await integration.execute_action("get_current_weather", {"location": "Raleigh"})
    assert result.success is False


@pytest.mark.asyncio
async def test_execute_get_current_weather_success(monkeypatch):
    monkeypatch.setattr("backend.integrations.weather_integration.settings.openweather_api_key", "fake-key")

    fake_payload = {
        "name": "Raleigh",
        "main": {"temp": 72.5, "feels_like": 70.0, "humidity": 40},
        "weather": [{"description": "clear sky"}],
    }

    async def fake_get(self, url, params=None):
        return FakeResponse(fake_payload)

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get)

    integration = WeatherIntegration()
    result = await integration.execute_action("get_current_weather", {"location": "Raleigh"})

    assert result.success is True
    assert result.data["location"] == "Raleigh"
    assert result.data["temperature_f"] == 72.5
    assert result.data["condition"] == "clear sky"
