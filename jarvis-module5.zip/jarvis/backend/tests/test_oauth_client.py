"""Tests for backend/integrations/oauth_client.py."""

from urllib.parse import parse_qs, urlparse

import httpx
import pytest

from backend.integrations.oauth_client import OAuthClient


def make_client() -> OAuthClient:
    return OAuthClient(
        authorize_url="https://example.com/authorize",
        token_url="https://example.com/token",
        client_id="client-abc",
        client_secret="secret-xyz",
        redirect_uri="http://127.0.0.1:8000/callback",
        scopes="read write",
    )


def test_build_authorization_url_includes_expected_params():
    client = make_client()
    url = client.build_authorization_url(state="state-123")

    parsed = urlparse(url)
    params = parse_qs(parsed.query)

    assert parsed.scheme + "://" + parsed.netloc + parsed.path == "https://example.com/authorize"
    assert params["client_id"] == ["client-abc"]
    assert params["response_type"] == ["code"]
    assert params["redirect_uri"] == ["http://127.0.0.1:8000/callback"]
    assert params["scope"] == ["read write"]
    assert params["state"] == ["state-123"]


class FakeTokenResponse:
    def __init__(self, payload: dict):
        self._payload = payload
        self.status_code = 200

    def json(self):
        return self._payload

    def raise_for_status(self):
        pass

    @property
    def text(self):
        return str(self._payload)


@pytest.mark.asyncio
async def test_exchange_code_for_token_parses_response(monkeypatch):
    async def fake_post(self, url, data=None):
        assert data["grant_type"] == "authorization_code"
        assert data["code"] == "the-code"
        return FakeTokenResponse(
            {"access_token": "access-1", "refresh_token": "refresh-1", "expires_in": 3600}
        )

    monkeypatch.setattr(httpx.AsyncClient, "post", fake_post)

    client = make_client()
    token = await client.exchange_code_for_token("the-code")

    assert token.access_token == "access-1"
    assert token.refresh_token == "refresh-1"
    assert token.expires_at is not None


@pytest.mark.asyncio
async def test_refresh_token_without_expires_in_has_no_expiry(monkeypatch):
    async def fake_post(self, url, data=None):
        assert data["grant_type"] == "refresh_token"
        return FakeTokenResponse({"access_token": "access-2"})

    monkeypatch.setattr(httpx.AsyncClient, "post", fake_post)

    client = make_client()
    token = await client.refresh_token("old-refresh")

    assert token.access_token == "access-2"
    assert token.expires_at is None
