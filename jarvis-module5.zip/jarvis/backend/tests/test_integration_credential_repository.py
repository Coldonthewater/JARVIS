"""Tests for backend/memory/repositories/integration_credential_repository.py."""

from datetime import datetime, timedelta, timezone

import pytest

from backend.memory.repositories.integration_credential_repository import (
    IntegrationCredentialRepository,
)


@pytest.mark.asyncio
async def test_save_and_get_round_trip(memory_db):
    repo = IntegrationCredentialRepository()
    expires_at = datetime.now(timezone.utc) + timedelta(hours=1)

    await repo.save("spotify", "access-123", "refresh-456", expires_at)
    credential = await repo.get("spotify")

    assert credential is not None
    assert credential.access_token == "access-123"
    assert credential.refresh_token == "refresh-456"


@pytest.mark.asyncio
async def test_get_missing_integration_returns_none(memory_db):
    repo = IntegrationCredentialRepository()
    assert await repo.get("not_connected") is None


@pytest.mark.asyncio
async def test_save_overwrites_existing_credential(memory_db):
    repo = IntegrationCredentialRepository()
    await repo.save("spotify", "old-token", "old-refresh", None)
    await repo.save("spotify", "new-token", "new-refresh", None)

    credential = await repo.get("spotify")
    assert credential.access_token == "new-token"
    assert credential.refresh_token == "new-refresh"


@pytest.mark.asyncio
async def test_save_preserves_refresh_token_when_not_provided(memory_db):
    repo = IntegrationCredentialRepository()
    await repo.save("spotify", "token-1", "refresh-1", None)
    await repo.save("spotify", "token-2", None, None)

    credential = await repo.get("spotify")
    assert credential.access_token == "token-2"
    assert credential.refresh_token == "refresh-1"


@pytest.mark.asyncio
async def test_delete_removes_credential(memory_db):
    repo = IntegrationCredentialRepository()
    await repo.save("spotify", "token", None, None)
    await repo.delete("spotify")
    assert await repo.get("spotify") is None
