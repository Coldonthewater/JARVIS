"""
Tests for backend/gateway/rest/integration_routes.py.

Uses FastAPI's TestClient against the real registry, but monkeypatches
individual integration instances with fakes so no real network calls
or OAuth provider is needed.
"""

import pytest
from fastapi.testclient import TestClient

from backend.gateway.rest.app import create_app
from backend.integrations.base import IntegrationActionResult, IntegrationStatus
from backend.integrations.registry import integration_registry


class FakeSimpleIntegration:
    """A non-OAuth integration, mimicking WeatherIntegration's shape."""

    name = "fake_simple"

    async def get_status(self):
        return IntegrationStatus.CONNECTED

    async def disconnect(self):
        pass

    async def execute_action(self, action, params):
        return IntegrationActionResult(success=True, data={"echo": params}, message="ok")


class FakeOAuthIntegration:
    """An OAuth-capable integration, mimicking Spotify/Google Calendar's shape."""

    name = "fake_oauth"

    def __init__(self):
        self.connected = False

    async def get_status(self):
        return IntegrationStatus.CONNECTED if self.connected else IntegrationStatus.NOT_CONFIGURED

    async def disconnect(self):
        self.connected = False

    async def execute_action(self, action, params):
        return IntegrationActionResult(success=True, data={}, message="ok")

    def get_authorization_url(self, state: str) -> str:
        return f"https://fake-provider.example.com/authorize?state={state}"

    async def handle_oauth_callback(self, code: str) -> None:
        self.connected = True


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr("backend.gateway.rest.routes.settings.gateway_auth_token", "test-token")

    fake_simple = FakeSimpleIntegration()
    fake_oauth = FakeOAuthIntegration()
    monkeypatch.setattr(
        integration_registry,
        "_integrations",
        {"fake_simple": fake_simple, "fake_oauth": fake_oauth},
    )

    app = create_app()
    test_client = TestClient(app)
    test_client.fake_oauth = fake_oauth
    return test_client


AUTH = {"Authorization": "Bearer test-token"}


def test_list_integrations_requires_auth(client):
    response = client.get("/integrations")
    assert response.status_code == 401


def test_list_integrations_returns_all(client):
    response = client.get("/integrations", headers=AUTH)
    assert response.status_code == 200
    names = {i["name"] for i in response.json()}
    assert names == {"fake_simple", "fake_oauth"}


def test_unknown_integration_returns_404(client):
    response = client.post("/integrations/does_not_exist/disconnect", headers=AUTH)
    assert response.status_code == 404


def test_authorize_on_non_oauth_integration_fails(client):
    response = client.get(
        "/integrations/fake_simple/authorize", headers=AUTH, follow_redirects=False
    )
    assert response.status_code == 400


def test_authorize_on_oauth_integration_redirects(client):
    response = client.get(
        "/integrations/fake_oauth/authorize", headers=AUTH, follow_redirects=False
    )
    assert response.status_code in (302, 307)
    assert "fake-provider.example.com" in response.headers["location"]


def test_callback_with_invalid_state_is_rejected(client):
    response = client.get(
        "/integrations/fake_oauth/callback", params={"code": "abc", "state": "bogus"}
    )
    assert response.status_code == 400


def test_callback_with_valid_state_connects_integration(client):
    authorize_response = client.get(
        "/integrations/fake_oauth/authorize", headers=AUTH, follow_redirects=False
    )
    location = authorize_response.headers["location"]
    state = location.split("state=")[1]

    callback_response = client.get(
        "/integrations/fake_oauth/callback", params={"code": "auth-code", "state": state}
    )
    assert callback_response.status_code == 200
    assert client.fake_oauth.connected is True


def test_execute_action_returns_result(client):
    response = client.post(
        "/integrations/fake_simple/execute",
        json={"action": "do_thing", "params": {"x": 1}},
        headers=AUTH,
    )
    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body["data"]["echo"] == {"x": 1}


def test_disconnect_returns_confirmation(client):
    response = client.post("/integrations/fake_simple/disconnect", headers=AUTH)
    assert response.status_code == 200
    assert response.json()["status"] == "disconnected"
