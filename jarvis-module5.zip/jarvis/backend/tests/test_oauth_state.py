"""Tests for backend/gateway/oauth_state.py."""

from backend.gateway.oauth_state import consume_state, generate_state


def test_generated_state_can_be_consumed_once():
    state = generate_state()
    assert consume_state(state) is True


def test_state_cannot_be_reused():
    state = generate_state()
    consume_state(state)
    assert consume_state(state) is False


def test_unknown_state_is_rejected():
    assert consume_state("never-issued") is False
