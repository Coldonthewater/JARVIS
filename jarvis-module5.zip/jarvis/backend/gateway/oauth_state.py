"""
OAuth state store — short-lived, single-use tokens that protect the
OAuth callback from cross-site request forgery.

Why this exists:
    The OAuth "state" parameter is a standard defense: Jarvis generates
    a random value before redirecting to the provider's consent page,
    and checks that the same value comes back on the callback. Without
    it, a malicious site could trick your browser into completing an
    OAuth flow with an attacker-supplied authorization code.

Design choice:
    In-memory with a short TTL is appropriate here — this is a
    single-user, localhost-only system, and a state token only needs
    to survive the few seconds between "redirect to consent page" and
    "provider redirects back". No need for database persistence.
"""

import secrets
import time

_TTL_SECONDS = 300  # 5 minutes — generous for a human to complete a consent screen
_pending_states: dict[str, float] = {}


def generate_state() -> str:
    state = secrets.token_urlsafe(24)
    _pending_states[state] = time.monotonic() + _TTL_SECONDS
    return state


def consume_state(state: str) -> bool:
    """
    Returns True if `state` was issued and not yet used/expired, and
    removes it (single-use). Returns False otherwise.
    """
    _cleanup_expired()
    expiry = _pending_states.pop(state, None)
    if expiry is None:
        return False
    return time.monotonic() <= expiry


def _cleanup_expired() -> None:
    now = time.monotonic()
    expired = [s for s, expiry in _pending_states.items() if expiry < now]
    for s in expired:
        _pending_states.pop(s, None)
