"""
Integration routes — list, connect (OAuth), disconnect, and execute
actions on integrations (Weather, Spotify, Google Calendar).

Route shape:
    GET  /integrations                          list all with status
    GET  /integrations/{name}/authorize          start OAuth (OAuth-capable only)
    GET  /integrations/{name}/callback           OAuth provider redirects here
    POST /integrations/{name}/disconnect         revoke/clear stored credentials
    POST /integrations/{name}/execute            run a named action

Auth note:
    Every route requires the gateway bearer token EXCEPT the OAuth
    callback — the provider (Spotify/Google) redirects the user's
    browser there directly and can't attach our bearer token. The
    OAuth `state` parameter is what protects that endpoint instead
    (see backend/gateway/oauth_state.py).
"""

from fastapi import APIRouter, Header, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse

from backend.core.logging_setup import get_logger
from backend.gateway.auth import require_auth
from backend.gateway.oauth_state import consume_state, generate_state
from backend.gateway.rest.schemas import (
    ExecuteActionRequest,
    ExecuteActionResponse,
    IntegrationStatusResponse,
)
from backend.integrations.base import IntegrationError, OAuthCapable
from backend.integrations.registry import integration_registry

logger = get_logger(__name__)
router = APIRouter(prefix="/integrations")


def _get_integration_or_404(name: str):
    integration = integration_registry.get(name)
    if integration is None:
        raise HTTPException(status_code=404, detail=f"Unknown integration '{name}'")
    return integration


@router.get("", response_model=list[IntegrationStatusResponse])
async def list_integrations(authorization: str | None = Header(default=None)) -> list[IntegrationStatusResponse]:
    require_auth(authorization)
    results = []
    for name, integration in integration_registry.all().items():
        status = await integration.get_status()
        results.append(
            IntegrationStatusResponse(
                name=name,
                status=status.value,
                oauth_capable=isinstance(integration, OAuthCapable),
            )
        )
    return results


@router.get("/{name}/authorize")
async def authorize(name: str, authorization: str | None = Header(default=None)) -> RedirectResponse:
    require_auth(authorization)
    integration = _get_integration_or_404(name)

    if not isinstance(integration, OAuthCapable):
        raise HTTPException(status_code=400, detail=f"'{name}' does not use OAuth")

    state = generate_state()
    url = integration.get_authorization_url(state)
    return RedirectResponse(url)


@router.get("/{name}/callback", response_class=HTMLResponse)
async def oauth_callback(name: str, code: str | None = None, state: str | None = None) -> str:
    """
    Unauthenticated by design — see module docstring. Protected instead
    by the single-use `state` token generated in /authorize.
    """
    integration = _get_integration_or_404(name)

    if not isinstance(integration, OAuthCapable):
        raise HTTPException(status_code=400, detail=f"'{name}' does not use OAuth")

    if not state or not consume_state(state):
        raise HTTPException(status_code=400, detail="Invalid or expired OAuth state")

    if not code:
        raise HTTPException(status_code=400, detail="Missing authorization code")

    try:
        await integration.handle_oauth_callback(code)
    except IntegrationError as exc:
        logger.error(f"OAuth callback failed for '{name}': {exc}")
        return f"<html><body><h2>Connection failed</h2><p>{exc}</p></body></html>"

    return f"<html><body><h2>{name} connected!</h2><p>You can close this tab and return to Jarvis.</p></body></html>"


@router.post("/{name}/disconnect")
async def disconnect(name: str, authorization: str | None = Header(default=None)) -> dict:
    require_auth(authorization)
    integration = _get_integration_or_404(name)
    await integration.disconnect()
    return {"status": "disconnected", "name": name}


@router.post("/{name}/execute", response_model=ExecuteActionResponse)
async def execute_action(
    name: str, body: ExecuteActionRequest, authorization: str | None = Header(default=None)
) -> ExecuteActionResponse:
    require_auth(authorization)
    integration = _get_integration_or_404(name)

    try:
        result = await integration.execute_action(body.action, body.params)
    except IntegrationError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return ExecuteActionResponse(success=result.success, data=result.data, message=result.message)
