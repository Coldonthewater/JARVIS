"""
Integration credential repository — stores and retrieves OAuth tokens
for integrations that need them (Spotify, Google Calendar).

Why separate from PreferenceRepository:
    Preferences are arbitrary user-facing key-value data; credentials
    have a distinct shape (access token, refresh token, expiry) and
    distinct handling (checking expiry, refreshing) that don't belong
    mixed into generic preference storage.
"""

from dataclasses import dataclass
from datetime import datetime

from backend.memory.database import get_session
from backend.memory.models import IntegrationCredential


@dataclass
class StoredCredential:
    integration_name: str
    access_token: str
    refresh_token: str | None
    expires_at: datetime | None


class IntegrationCredentialRepository:
    async def save(
        self,
        integration_name: str,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: datetime | None = None,
    ) -> None:
        async with get_session() as session:
            existing = await session.get(IntegrationCredential, integration_name)
            if existing:
                existing.access_token = access_token
                if refresh_token is not None:
                    existing.refresh_token = refresh_token
                existing.expires_at = expires_at
            else:
                session.add(
                    IntegrationCredential(
                        integration_name=integration_name,
                        access_token=access_token,
                        refresh_token=refresh_token,
                        expires_at=expires_at,
                    )
                )
            await session.commit()

    async def get(self, integration_name: str) -> StoredCredential | None:
        async with get_session() as session:
            row = await session.get(IntegrationCredential, integration_name)
            if row is None:
                return None
            return StoredCredential(
                integration_name=row.integration_name,
                access_token=row.access_token,
                refresh_token=row.refresh_token,
                expires_at=row.expires_at,
            )

    async def delete(self, integration_name: str) -> None:
        async with get_session() as session:
            row = await session.get(IntegrationCredential, integration_name)
            if row:
                await session.delete(row)
                await session.commit()


# Application-wide singleton.
integration_credential_repository = IntegrationCredentialRepository()
