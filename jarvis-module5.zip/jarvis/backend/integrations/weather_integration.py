"""
Weather integration — the simplest kind: configured entirely via an
API key in settings/.env, no OAuth consent flow needed.

Setup:
    Get a free API key from https://openweathermap.org/api and set
    OPENWEATHER_API_KEY in config/.env.

Supported actions:
    get_current_weather(location: str) -> current conditions for a
    city name (e.g. "Raleigh,US").
"""

import httpx

from backend.core.config import settings
from backend.core.logging_setup import get_logger
from backend.integrations.base import IntegrationActionResult, IntegrationError, IntegrationStatus

logger = get_logger(__name__)

BASE_URL = "https://api.openweathermap.org/data/2.5/weather"


class WeatherIntegration:
    name = "weather"

    async def get_status(self) -> IntegrationStatus:
        return (
            IntegrationStatus.CONNECTED
            if settings.openweather_api_key
            else IntegrationStatus.NOT_CONFIGURED
        )

    async def disconnect(self) -> None:
        # Nothing to revoke — the "connection" is just the API key in
        # .env. Disconnecting means removing that key, which is a
        # config change, not something this method can do.
        logger.info("Weather has no stored session to disconnect — remove OPENWEATHER_API_KEY from .env instead")

    async def execute_action(self, action: str, params: dict) -> IntegrationActionResult:
        if action != "get_current_weather":
            return IntegrationActionResult(success=False, message=f"Unknown action '{action}'")

        if not settings.openweather_api_key:
            return IntegrationActionResult(
                success=False, message="OPENWEATHER_API_KEY is not set in config/.env"
            )

        location = params.get("location")
        if not location:
            return IntegrationActionResult(success=False, message="Missing required param 'location'")

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    BASE_URL,
                    params={
                        "q": location,
                        "appid": settings.openweather_api_key,
                        "units": "imperial",
                    },
                )
                response.raise_for_status()
                data = response.json()
        except httpx.HTTPStatusError as exc:
            raise IntegrationError(f"Weather API error: {exc.response.text}") from exc
        except httpx.RequestError as exc:
            raise IntegrationError(f"Could not reach weather API: {exc}") from exc

        return IntegrationActionResult(
            success=True,
            data={
                "location": data.get("name", location),
                "temperature_f": data["main"]["temp"],
                "feels_like_f": data["main"]["feels_like"],
                "condition": data["weather"][0]["description"],
                "humidity_percent": data["main"]["humidity"],
            },
        )
