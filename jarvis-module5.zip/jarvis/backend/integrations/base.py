"""
The Integration interface — the contract every external service
connector implements.

Why this exists:
    Same reasoning as backend/ai/base.py's AIProvider: the rest of
    Jarvis (gateway, and eventually the AI engine calling actions on
    your behalf) should never special-case "if integration is Spotify,
    do X". Every integration exposes the same shape, so adding a new
    one is a new file implementing this interface plus one registry
    entry — no changes anywhere else.

Two flavors of integration:
    - API-key integrations (e.g. Weather): configured entirely via
      settings/.env, no user interaction needed to "connect" — they're
      either configured or they're not.
    - OAuth integrations (e.g. Spotify, Google Calendar): need a
      multi-step browser consent flow before they're usable. These
      additionally implement `OAuthCapable` (get_authorization_url,
      handle_oauth_callback) on top of the base `Integration` interface.
      The gateway checks `isinstance(integration, OAuthCapable)` (a
      runtime-checkable Protocol) to decide whether to expose the
      OAuth routes for a given integration.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class IntegrationStatus(str, Enum):
    NOT_CONFIGURED = "not_configured"  # API key missing, or OAuth never completed
    CONNECTED = "connected"
    ERROR = "error"


@dataclass
class IntegrationActionResult:
    success: bool
    data: dict[str, Any] = field(default_factory=dict)
    message: str = ""


class IntegrationError(Exception):
    """Raised by an integration when an action fails (API error, expired auth, etc.)."""


class Integration(Protocol):
    name: str

    async def get_status(self) -> IntegrationStatus: ...

    async def disconnect(self) -> None:
        """Revokes/clears whatever makes this integration usable (stored tokens, etc.)."""
        ...

    async def execute_action(self, action: str, params: dict[str, Any]) -> IntegrationActionResult:
        """
        Performs a named action, e.g. execute_action("get_current_weather", {"location": "Raleigh"}).
        Each integration documents its own supported action names.
        """
        ...


@runtime_checkable
class OAuthCapable(Protocol):
    """
    Additional interface for integrations that need a browser-based
    OAuth consent flow before they're usable. Checked via
    `isinstance(integration, OAuthCapable)` since not every Integration
    implements this.
    """

    def get_authorization_url(self, state: str) -> str:
        """Builds the URL the user visits in a browser to grant access."""
        ...

    async def handle_oauth_callback(self, code: str) -> None:
        """Exchanges the authorization code for tokens and persists them."""
        ...
