"""
Integration registry — the single lookup point for every configured
integration.

Why this exists:
    Same pattern as AIEngine._providers — one dict every caller (the
    gateway routes) looks up by name, instead of importing each
    integration file individually wherever it's needed.

Adding a new integration later:
    1. Write backend/integrations/newservice_integration.py implementing
       the `Integration` interface (and `OAuthCapable` if it needs OAuth).
    2. Add one line to `_integrations` below.
    No other file changes needed.
"""

from backend.integrations.base import Integration
from backend.integrations.google_calendar_integration import GoogleCalendarIntegration
from backend.integrations.spotify_integration import SpotifyIntegration
from backend.integrations.weather_integration import WeatherIntegration


class IntegrationRegistry:
    def __init__(self) -> None:
        self._integrations: dict[str, Integration] = {
            "weather": WeatherIntegration(),
            "spotify": SpotifyIntegration(),
            "google_calendar": GoogleCalendarIntegration(),
        }

    def get(self, name: str) -> Integration | None:
        return self._integrations.get(name)

    def all(self) -> dict[str, Integration]:
        return dict(self._integrations)


# Application-wide singleton.
integration_registry = IntegrationRegistry()
