"""
Spotify integration — OAuth2, for reading/controlling playback.

Setup:
    1. Create an app at https://developer.spotify.com/dashboard
    2. Add the redirect URI from config/.env (SPOTIFY_REDIRECT_URI,
       defaults to http://127.0.0.1:8000/integrations/spotify/callback)
       as an allowed redirect URI in the Spotify app settings.
    3. Set SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET in config/.env.
    4. Visit GET /integrations/spotify/authorize (via the gateway) to
       start the consent flow.

Supported actions:
    get_current_track  -> what's currently playing, if anything
    play                -> resume playback
    pause               -> pause playback
"""

from datetime import datetime, timezone

import httpx

from backend.core.config import settings
from backend.core.logging_setup import get_logger
from backend.integrations.base import IntegrationActionResult, IntegrationError, IntegrationStatus
from backend.integrations.oauth_client import OAuthClient
from backend.memory.repositories.integration_credential_repository import (
    integration_credential_repository,
)

logger = get_logger(__name__)

AUTHORIZE_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API_BASE = "https://api.spotify.com/v1"
SCOPES = "user-read-playback-state user-modify-playback-state"


class SpotifyIntegration:
    name = "spotify"

    def _oauth_client(self) -> OAuthClient:
        return OAuthClient(
            authorize_url=AUTHORIZE_URL,
            token_url=TOKEN_URL,
            client_id=settings.spotify_client_id or "",
            client_secret=settings.spotify_client_secret or "",
            redirect_uri=settings.spotify_redirect_uri,
            scopes=SCOPES,
        )

    def get_authorization_url(self, state: str) -> str:
        return self._oauth_client().build_authorization_url(state)

    async def handle_oauth_callback(self, code: str) -> None:
        token = await self._oauth_client().exchange_code_for_token(code)
        await integration_credential_repository.save(
            self.name, token.access_token, token.refresh_token, token.expires_at
        )
        logger.info("Spotify connected successfully")

    async def get_status(self) -> IntegrationStatus:
        credential = await integration_credential_repository.get(self.name)
        return IntegrationStatus.CONNECTED if credential else IntegrationStatus.NOT_CONFIGURED

    async def disconnect(self) -> None:
        await integration_credential_repository.delete(self.name)
        logger.info("Spotify disconnected")

    async def _get_valid_access_token(self) -> str:
        credential = await integration_credential_repository.get(self.name)
        if credential is None:
            raise IntegrationError("Spotify is not connected — visit /integrations/spotify/authorize first")

        is_expired = credential.expires_at is not None and credential.expires_at <= datetime.now(timezone.utc)
        if is_expired and credential.refresh_token:
            token = await self._oauth_client().refresh_token(credential.refresh_token)
            # Spotify often omits refresh_token on refresh responses —
            # keep the existing one in that case.
            new_refresh_token = token.refresh_token or credential.refresh_token
            await integration_credential_repository.save(
                self.name, token.access_token, new_refresh_token, token.expires_at
            )
            return token.access_token

        return credential.access_token

    async def execute_action(self, action: str, params: dict) -> IntegrationActionResult:
        access_token = await self._get_valid_access_token()
        headers = {"Authorization": f"Bearer {access_token}"}

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                if action == "get_current_track":
                    response = await client.get(f"{API_BASE}/me/player/currently-playing", headers=headers)
                    if response.status_code == 204:
                        return IntegrationActionResult(success=True, data={"playing": False})
                    response.raise_for_status()
                    data = response.json()
                    item = data.get("item") or {}
                    return IntegrationActionResult(
                        success=True,
                        data={
                            "playing": data.get("is_playing", False),
                            "track": item.get("name"),
                            "artist": ", ".join(a["name"] for a in item.get("artists", [])),
                        },
                    )
                elif action == "play":
                    response = await client.put(f"{API_BASE}/me/player/play", headers=headers)
                    response.raise_for_status()
                    return IntegrationActionResult(success=True, message="Playback resumed")
                elif action == "pause":
                    response = await client.put(f"{API_BASE}/me/player/pause", headers=headers)
                    response.raise_for_status()
                    return IntegrationActionResult(success=True, message="Playback paused")
                else:
                    return IntegrationActionResult(success=False, message=f"Unknown action '{action}'")
        except httpx.HTTPStatusError as exc:
            raise IntegrationError(f"Spotify API error: {exc.response.text}") from exc
        except httpx.RequestError as exc:
            raise IntegrationError(f"Could not reach Spotify: {exc}") from exc
