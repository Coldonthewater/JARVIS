"""
Google Calendar integration — OAuth2, for reading upcoming events.

Setup:
    1. Create a project and OAuth client at
       https://console.cloud.google.com/apis/credentials, enable the
       Google Calendar API for it.
    2. Add the redirect URI from config/.env
       (GOOGLE_CALENDAR_REDIRECT_URI, defaults to
       http://127.0.0.1:8000/integrations/google_calendar/callback)
       as an authorized redirect URI.
    3. Set GOOGLE_CALENDAR_CLIENT_ID and GOOGLE_CALENDAR_CLIENT_SECRET
       in config/.env. (This is a separate app registration from
       GOOGLE_API_KEY, which is for Gemini — Google's AI API and
       Calendar API use unrelated credentials.)
    4. Visit GET /integrations/google_calendar/authorize (via the
       gateway) to start the consent flow.

Supported actions:
    list_upcoming_events(max_results: int = 5) -> the next N events on
    the primary calendar.
"""

from datetime import datetime, timezone

import httpx

from backend.core.config import settings
from backend.core.logging_setup import get_logger
from backend.integrations.base import IntegrationActionResult, IntegrationError, IntegrationStatus
from backend.integrations.oauth_client import OAuthClient
from backend.memory.repositories.integration_credential_repository import (
    integration_credential_repository,
)

logger = get_logger(__name__)

AUTHORIZE_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
API_BASE = "https://www.googleapis.com/calendar/v3"
SCOPES = "https://www.googleapis.com/auth/calendar.readonly"


class GoogleCalendarIntegration:
    name = "google_calendar"

    def _oauth_client(self) -> OAuthClient:
        return OAuthClient(
            authorize_url=AUTHORIZE_URL,
            token_url=TOKEN_URL,
            client_id=settings.google_calendar_client_id or "",
            client_secret=settings.google_calendar_client_secret or "",
            redirect_uri=settings.google_calendar_redirect_uri,
            scopes=SCOPES,
        )

    def get_authorization_url(self, state: str) -> str:
        # Google requires access_type=offline + prompt=consent to
        # reliably receive a refresh_token — the shared OAuthClient
        # doesn't know about this Google-specific quirk, so it's added
        # here rather than generalizing the shared helper for one provider.
        base_url = self._oauth_client().build_authorization_url(state)
        return f"{base_url}&access_type=offline&prompt=consent"

    async def handle_oauth_callback(self, code: str) -> None:
        token = await self._oauth_client().exchange_code_for_token(code)
        await integration_credential_repository.save(
            self.name, token.access_token, token.refresh_token, token.expires_at
        )
        logger.info("Google Calendar connected successfully")

    async def get_status(self) -> IntegrationStatus:
        credential = await integration_credential_repository.get(self.name)
        return IntegrationStatus.CONNECTED if credential else IntegrationStatus.NOT_CONFIGURED

    async def disconnect(self) -> None:
        await integration_credential_repository.delete(self.name)
        logger.info("Google Calendar disconnected")

    async def _get_valid_access_token(self) -> str:
        credential = await integration_credential_repository.get(self.name)
        if credential is None:
            raise IntegrationError(
                "Google Calendar is not connected — visit /integrations/google_calendar/authorize first"
            )

        is_expired = credential.expires_at is not None and credential.expires_at <= datetime.now(timezone.utc)
        if is_expired and credential.refresh_token:
            token = await self._oauth_client().refresh_token(credential.refresh_token)
            new_refresh_token = token.refresh_token or credential.refresh_token
            await integration_credential_repository.save(
                self.name, token.access_token, new_refresh_token, token.expires_at
            )
            return token.access_token

        return credential.access_token

    async def execute_action(self, action: str, params: dict) -> IntegrationActionResult:
        if action != "list_upcoming_events":
            return IntegrationActionResult(success=False, message=f"Unknown action '{action}'")

        access_token = await self._get_valid_access_token()
        max_results = params.get("max_results", 5)
        now_iso = datetime.now(timezone.utc).isoformat()

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    f"{API_BASE}/calendars/primary/events",
                    headers={"Authorization": f"Bearer {access_token}"},
                    params={
                        "timeMin": now_iso,
                        "maxResults": max_results,
                        "singleEvents": "true",
                        "orderBy": "startTime",
                    },
                )
                response.raise_for_status()
                data = response.json()
        except httpx.HTTPStatusError as exc:
            raise IntegrationError(f"Google Calendar API error: {exc.response.text}") from exc
        except httpx.RequestError as exc:
            raise IntegrationError(f"Could not reach Google Calendar: {exc}") from exc

        events = [
            {
                "summary": event.get("summary", "(no title)"),
                "start": event.get("start", {}).get("dateTime") or event.get("start", {}).get("date"),
            }
            for event in data.get("items", [])
        ]
        return IntegrationActionResult(success=True, data={"events": events})
