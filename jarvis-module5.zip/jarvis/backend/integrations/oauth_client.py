"""
Shared OAuth2 (authorization code flow) helper.

Why this exists:
    Spotify and Google Calendar both use the same standard OAuth2
    authorization-code flow (build a consent URL, redirect the user,
    exchange the returned code for tokens, refresh when expired).
    Rather than duplicating that HTTP plumbing in both integration
    files, it lives here once — each integration file only needs to
    supply its own URLs, client credentials, and scopes.

Design choice:
    Plain httpx calls rather than a dedicated OAuth library (e.g.
    authlib) — the authorization-code flow is a handful of well-defined
    HTTP calls, and avoiding an extra dependency keeps this consistent
    with how the AI providers already talk to Ollama/APIs directly.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

import httpx

from backend.core.logging_setup import get_logger
from backend.integrations.base import IntegrationError

logger = get_logger(__name__)


@dataclass
class TokenResponse:
    access_token: str
    refresh_token: str | None
    expires_at: datetime | None


class OAuthClient:
    def __init__(
        self,
        authorize_url: str,
        token_url: str,
        client_id: str,
        client_secret: str,
        redirect_uri: str,
        scopes: str,
    ) -> None:
        self.authorize_url = authorize_url
        self.token_url = token_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.scopes = scopes

    def build_authorization_url(self, state: str) -> str:
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "scope": self.scopes,
            "state": state,
        }
        return f"{self.authorize_url}?{urlencode(params)}"

    async def exchange_code_for_token(self, code: str) -> TokenResponse:
        return await self._post_token_request(
            {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": self.redirect_uri,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
        )

    async def refresh_token(self, refresh_token: str) -> TokenResponse:
        return await self._post_token_request(
            {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
        )

    async def _post_token_request(self, data: dict[str, str]) -> TokenResponse:
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(self.token_url, data=data)
                response.raise_for_status()
                payload = response.json()
        except httpx.HTTPStatusError as exc:
            raise IntegrationError(f"OAuth token request failed: {exc.response.text}") from exc
        except httpx.RequestError as exc:
            raise IntegrationError(f"Could not reach token endpoint: {exc}") from exc

        expires_in = payload.get("expires_in")
        expires_at = (
            datetime.now(timezone.utc) + timedelta(seconds=int(expires_in))
            if expires_in is not None
            else None
        )

        return TokenResponse(
            access_token=payload["access_token"],
            # Some providers only return a refresh_token on the very
            # first exchange, not on subsequent refreshes — callers
            # should preserve the old one if this comes back empty.
            refresh_token=payload.get("refresh_token"),
            expires_at=expires_at,
        )
